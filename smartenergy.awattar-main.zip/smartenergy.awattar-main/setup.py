"""Package setup"""

from setuptools import setup

setup()
